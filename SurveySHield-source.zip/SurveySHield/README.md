# SurveySignal

A private survey workspace for student clubs and small organisations, built for Shreyas L (2102508662).

## Features

- Survey creation, editing, drafts, publishing, closing, duplication and deletion.
- Single choice, multiple choice, dropdown, rating, yes/no, short text and long text questions.
- Validated response collection with required fields and academic year/department dimensions.
- Persistent surveys and responses in Cloudflare D1.
- Live dashboard, question insights and server-calculated group distributions.
- Academic-year and department comparisons, grouped/stacked charts and exact distribution tables.
- Survey and response search, pagination, filters and CSV export.
- Responsive navigation, subtle 3D metric hover and motion preferences.

## Development

```sh
npm install
npm run dev
```

This hosted edition uses React, TypeScript, Vinext/Vite, Recharts, Lucide and a Cloudflare Worker API. The original Express/Mongoose stack in the brief cannot run on Sites' Worker hosting; MongoDB Atlas connectivity is not configured. This is a hosted adaptation, not an Express/MongoDB implementation.

## Database

The `DB` D1 binding is declared in `.openai/hosting.json`. Sites provisions storage and applies committed schema migrations on deployment. No database credentials are embedded in source.

For local setup, build once and apply each migration in order:

```sh
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_complex_husk.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_slimy_sandman.sql
```

Use the actual committed migration filename if it differs. Local preview and deployed data are separate. The initial workspace contains clearly labelled sample surveys and responses stored as editable records. First-run initialization is recorded so deleting all surveys does not re-seed them.

## Verification

```sh
node scripts/test-survey.mjs
node scripts/test-api.mjs
node scripts/test-access.mjs
node scripts/test-auth.mjs
npx tsc --noEmit
npm run build
```

Core tests cover denominators, missing answers, zero-size groups, multi-select results, rating bounds and validation. Browser QA covers rendering, survey publishing, submission confirmation and updated response statistics.

## Login, ownership and privacy

Routes: `/login`, `/admin` (your survey-owner workspace), `/dashboard` (survey participation and personal history), `/privacy`, and a custom 404 page.

**Ownership is per survey.** Any authenticated user can create a survey. The server assigns `owner_id` from that verified account. Only that creator can edit, publish, close or delete it, read its responses, export its records and calculate its comparisons. The client cannot assign or transfer ownership. Other users can participate in published surveys, view their own submissions and delete those submissions. A person can own one survey and be a user of another.

The server-only `ADMIN_EMAIL` setting is retained only to assign legacy records and load initial samples for the original workspace owner. It does not grant access to surveys created by other accounts.

### Authentication

Supabase integration supports:

- Google OAuth with PKCE through `/auth/google` and `/auth/callback`.
- Email sign-in links through `/api/auth`, returning to `/auth/callback` in the same browser.
- Mobile sign-in with SMS verification codes through `/api/auth`.
- The existing ChatGPT sign-in as an additional fallback.

The app uses `@supabase/ssr` with HttpOnly, SameSite cookies and server-verified `getUser()` identities. Middleware refreshes sessions. Provider `user_metadata` is used only for a display name, never ownership or authorization. Tokens and service-role keys are not put in client bundles. Google/email/mobile controls show setup status until configured; they never simulate a successful login.

Configure these runtime values in Sites:

- `SUPABASE_URL`: the selected project's HTTPS URL.
- `SUPABASE_PUBLISHABLE_KEY`: its publishable key, never a service-role/secret key.
- `AUTH_GOOGLE_ENABLED=true` only after Google OAuth is configured.
- `AUTH_EMAIL_ENABLED=true` for email links.
- `AUTH_PHONE_ENABLED=true` only after an SMS provider is configured.
- `ADMIN_EMAIL`: the verified original owner's email, only for legacy data/sample setup.
- `DB`: the D1 binding in the hosting manifest.

In Supabase, set the Site URL to your deployed Site origin, and allow the exact `/auth/callback` URL. Configure the Google provider with its OAuth client, and configure phone authentication with an SMS provider. Google/email/mobile flows have automated tests with mock provider responses; real provider delivery must be tested after project configuration.

The Supabase connection is confirmed, but project-management tools are not exposed in this session. No Supabase project, provider settings or live verification deliveries have been changed or verified yet.

### Schema and privacy

For a fresh local database, apply all committed D1 migrations in order, including `0002_workable_madame_web.sql` (members and response account links) and `0003_peaceful_caretaker.sql` (survey ownership). Hosted publication applies pending migrations.

Legacy responses have a nullable `user_id` and cannot be claimed by arbitrary members. Legacy surveys are assigned only to the verified original owner. Existing responses and survey definitions are retained.

The current Site audience is preserved. Public visitors can view login and policy pages; dashboards and data APIs require verified identity. The policy explains provider identity, account linking, owner access, storage, fonts, preferences and deletion. Hiding respondent names is not full anonymity because account links remain for response management.

## Structure

- `components/workspace.tsx` — admin workspace, builder, response form and chart screens
- `components/user-dashboard.tsx` — member dashboard and own submissions
- `app/login/`, `app/privacy/` and `app/not-found.tsx` — public login and information pages
- `lib/access.ts` — trusted identity and role assignment
- `app/globals.css` — responsive design and motion
- `app/api/data/route.ts` — persistence, validation and comparisons
- `lib/survey.ts` — shared types, validators, distribution engine and initial sample data
- `db/` and `drizzle/` — schema and migrations
- `scripts/test-*.mjs` — focused tests

Percentages use valid respondents in each group. Missing optional answers are excluded. Multi-select percentages may total above 100%. Empty groups return zero. Surveys with existing responses preserve their question definitions; duplicate a survey to change those questions.

## Limits

This edition loads workspace responses in one request and is intended for small club datasets. It does not implement an external notification service, password-based accounts, ownership transfer, start/completion tracking, duplicate-submission detection, or a comprehensive distributed rate limiter.
