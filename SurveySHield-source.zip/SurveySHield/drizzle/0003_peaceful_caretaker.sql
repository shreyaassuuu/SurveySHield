ALTER TABLE `surveys` ADD `owner_id` text;--> statement-breakpoint
CREATE INDEX `survey_owner_idx` ON `surveys` (`owner_id`);