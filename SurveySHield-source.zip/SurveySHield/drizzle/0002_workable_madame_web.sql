CREATE TABLE `members` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`name` text NOT NULL,
	`role` text NOT NULL,
	`joined_at` text NOT NULL
);
--> statement-breakpoint
ALTER TABLE `responses` ADD `user_id` text;--> statement-breakpoint
CREATE INDEX `response_user_idx` ON `responses` (`user_id`);