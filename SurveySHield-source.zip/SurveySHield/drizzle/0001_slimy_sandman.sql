CREATE TABLE `workspace_meta` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `response_survey_idx` ON `responses` (`survey_id`);