import { redirect } from 'next/navigation';
import {getViewer} from '../lib/access';
export const dynamic='force-dynamic';
export default async function Home(){const user=await getViewer();redirect(!user?'/login':'/dashboard');}
