import {authClient} from '../../../lib/supabase-server';
import {NextResponse} from 'next/server';
export async function GET(req:Request){const supabase=await authClient();if(supabase)await supabase.auth.signOut({scope:'local'});return NextResponse.redirect(new URL('/signout-with-chatgpt?return_to=%2Flogin',req.url));}
