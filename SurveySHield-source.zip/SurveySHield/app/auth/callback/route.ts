import {authClient} from '../../../lib/supabase-server';
import {NextResponse} from 'next/server';
export async function GET(req:Request){const code=new URL(req.url).searchParams.get('code');const supabase=await authClient();if(code&&supabase){const {error}=await supabase.auth.exchangeCodeForSession(code);if(!error)return NextResponse.redirect(new URL('/dashboard',req.url));}return NextResponse.redirect(new URL('/login?error=auth_failed',req.url));}
