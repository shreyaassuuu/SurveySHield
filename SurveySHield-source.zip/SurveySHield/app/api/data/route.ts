import {getViewer} from '../../../lib/access';
import {env} from 'cloudflare:workers';
import {distribution, years, departments, validateSurvey, validateAnswers, buildSample} from '../../../lib/survey';
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export const dynamic='force-dynamic';
export async function GET(req?:Request){try{
 const viewer=await getViewer();if(!viewer)return json({error:'Sign in to open your workspace.'},401);
 // Only the verified original workspace owner can claim pre-ownership records.
 if(viewer.role==='admin')await env.DB!.prepare('UPDATE surveys SET owner_id=? WHERE owner_id IS NULL').bind(viewer.userId).run();
 const own=new URL(req?.url||'https://site/api/data').searchParams.get('scope')==='mine';
 const [s,r]=await Promise.all([
 own?env.DB!.prepare('SELECT data,owner_id FROM surveys').all():env.DB!.prepare('SELECT data,owner_id FROM surveys WHERE owner_id=?').bind(viewer.userId).all(),
 own?env.DB!.prepare('SELECT data FROM responses WHERE user_id=?').bind(viewer.userId).all():env.DB!.prepare('SELECT responses.data FROM responses JOIN surveys ON responses.survey_id=surveys.id WHERE surveys.owner_id=?').bind(viewer.userId).all()
 ]);
 const responses=r.results.map((x:any)=>JSON.parse(x.data));const all=s.results.map((x:any)=>({...JSON.parse(x.data),ownerId:x.owner_id}));
 const surveys=own?all.filter((s:any)=>s.status==='Active'||responses.some((r:any)=>r.surveyId===s.id)):all;
 return json({surveys,responses,viewer,members:[]});
 }catch{return json({error:'The workspace could not be loaded. Please try again.'},500)}}
export async function POST(req:Request){try{
 if(Number(req.headers.get('content-length')||0)>1048576)return json({error:'Request too large'},413);
 const raw=await req.text();if(raw.length>1048576)return json({error:'Request too large'},413);let payload:any;try{payload=JSON.parse(raw)}catch{return json({error:'Invalid JSON body.'},400)}if(!payload||typeof payload!=='object')return json({error:'Invalid request.'},400);const {action,survey,response,id,...options}=payload;
 const viewer=await getViewer();if(!viewer)return json({error:'Sign in to continue.'},401);
 const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)return json({error:'Invalid request origin.'},403);
 if(action==='seed'&&viewer.role!=='admin')return json({error:'Only the original workspace owner can load sample surveys.'},403);
 if(action==='delete-own-response'){await env.DB!.prepare('DELETE FROM responses WHERE id=? AND user_id=?').bind(id,viewer.userId).run();return json({ok:true});}
 if(action==='seed'){
 const exists=await env.DB!.prepare("SELECT value FROM workspace_meta WHERE key='initialized'").first();if(exists)return json({ok:true});
 const data=buildSample();await env.DB!.batch([env.DB!.prepare("INSERT OR IGNORE INTO workspace_meta (key,value) VALUES ('initialized','true')"),...data.surveys.map((s:any)=>env.DB!.prepare('INSERT OR IGNORE INTO surveys (id,owner_id,data) VALUES (?,?,?)').bind(s.id,viewer.userId,JSON.stringify({...s,ownerId:viewer.userId}))),...data.responses.map((r:any)=>env.DB!.prepare('INSERT OR IGNORE INTO responses (id,survey_id,data) VALUES (?,?,?)').bind(r.id,r.surveyId,JSON.stringify(r)))]);return json({ok:true});
 }
 if(action==='compare'){
 const {questionId,dimension,groups,range,year,department}=options;
 if(!['year','department'].includes(dimension)||!Array.isArray(groups)||groups.some((g:any)=>!(dimension==='year'?years:departments).includes(g))||!['7','30','90','all'].includes(range))return json({error:'Invalid comparison filters.'},400);
 const row=await env.DB!.prepare('SELECT data,owner_id FROM surveys WHERE id=?').bind(id).first<any>();if(!row)return json({error:'Survey not found'},404);if(row.owner_id!==viewer.userId)return json({error:'Only this survey’s owner can view comparisons.'},403);const s=JSON.parse(row.data);if(!s.questions.some((q:any)=>q.id===questionId))return json({error:'Question not found'},400);
 const results=await env.DB!.prepare('SELECT data FROM responses WHERE survey_id=?').bind(id).all();const rs=results.results.map((r:any)=>JSON.parse(r.data)).filter((r:any)=>(range==='all'||new Date(r.submittedAt)>=new Date(Date.now()-Number(range)*864e5))&&(!year||year==='all'||r.year===year)&&(!department||department==='all'||r.department===department));
 return json({distribution:distribution(s,rs,questionId,dimension,groups)});
 }
 if(action==='save'){
 const error=validateSurvey(survey);if(error)return json({error},400);
 const existing=await env.DB!.prepare('SELECT data,owner_id FROM surveys WHERE id=?').bind(survey.id).first<any>();
 if(existing&&existing.owner_id!==viewer.userId)return json({error:'Only this survey’s owner can edit it.'},403);
 survey.ownerId=viewer.userId;
 if(existing){const old=JSON.parse(existing.data);const count=await env.DB!.prepare('SELECT COUNT(*) AS n FROM responses WHERE survey_id=?').bind(survey.id).first<any>();if(count?.n && JSON.stringify(old.questions)!==JSON.stringify(survey.questions))return json({error:'This survey has responses. Duplicate it to change its questions.'},400);}
 survey.updatedAt=new Date().toISOString();await env.DB!.prepare('INSERT INTO surveys (id,owner_id,data) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').bind(survey.id,viewer.userId,JSON.stringify(survey)).run();return json({ok:true});
 }
 if(action==='delete'){const row=await env.DB!.prepare('SELECT data,owner_id FROM surveys WHERE id=?').bind(id).first<any>();if(!row)return json({error:'Survey not found'},404);if(row.owner_id!==viewer.userId)return json({error:'Only this survey’s owner can delete it.'},403);await env.DB!.batch([env.DB!.prepare('DELETE FROM responses WHERE survey_id=?').bind(id),env.DB!.prepare('DELETE FROM surveys WHERE id=?').bind(id)]);return json({ok:true});}
 if(action==='respond'){
 const row=await env.DB!.prepare('SELECT data,owner_id FROM surveys WHERE id=?').bind(response?.surveyId||'').first<any>();if(!row)return json({error:'Survey not found'},404);
 const s=JSON.parse(row.data);if(s.status!=='Active'||(s.closingDate&&new Date(s.closingDate+'T23:59:59')<new Date()))return json({error:'This survey is not accepting responses.'},400);
 const error=validateAnswers(s,response);if(error)return json({error},400);
 const record={id:crypto.randomUUID(),userId:viewer.userId,surveyId:s.id,name:s.anonymous?'Anonymous':String(response.name||'Anonymous').slice(0,100),year:response.year,department:response.department,answers:response.answers,submittedAt:new Date().toISOString()};await env.DB!.prepare('INSERT INTO responses (id,survey_id,user_id,data) VALUES (?,?,?,?)').bind(record.id,s.id,viewer.userId,JSON.stringify(record)).run();return json({ok:true});
 }
 return json({error:'Unknown action'},400);
 }catch(e){console.error(e);return json({error:'Unable to save your changes. Please try again.'},500)}}
