import {authClient,authConfiguration} from '../../../lib/supabase-server';
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(req:Request){try{
 const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)return json({error:'Invalid request origin.'},403);
 if(Number(req.headers.get('content-length')||0)>4096)return json({error:'Request too large.'},413);
 const raw=await req.text();if(raw.length>4096)return json({error:'Request too large.'},413);
 let body:any;try{body=JSON.parse(raw)}catch{return json({error:'Invalid request.'},400)}
 const cfg=authConfiguration();const supabase=await authClient();if(!supabase)return json({error:'Sign-in provider setup is not complete yet.'},503);
 const email=String(body.email||'').trim();const phone=String(body.phone||'').trim();
 if(body.mode==='email'&&(!cfg.email||!/^\S+@\S+\.\S+$/.test(email)))return json({error:'Enter a valid email address. Email sign-in must be enabled.'},400);
 if(body.mode==='phone'&&(!cfg.phone||!/^\+[1-9]\d{7,14}$/.test(phone)))return json({error:'Enter a mobile number with its country code. Mobile sign-in must be enabled.'},400);
 if(!['email','phone'].includes(body.mode))return json({error:'Invalid sign-in method.'},400);
 let error:any;
 if(body.action==='send'){
  ({error}=body.mode==='email'?await supabase.auth.signInWithOtp({email,options:{emailRedirectTo:new URL('/auth/callback',req.url).toString(),shouldCreateUser:true}}):await supabase.auth.signInWithOtp({phone,options:{shouldCreateUser:true}}));
 }else if(body.action==='verify'){
  const token=String(body.token||'').trim();if(!/^\d{6,8}$/.test(token))return json({error:'Enter the verification code from your message.'},400);
  ({error}=body.mode==='email'?await supabase.auth.verifyOtp({email,token,type:'email'}):await supabase.auth.verifyOtp({phone,token,type:'sms'}));
 }else return json({error:'Invalid action.'},400);
 if(error)return json({error:error.status===429?'Too many attempts. Please wait before trying again.':'Unable to complete sign-in. Check your details or request a new code.'},error.status===429?429:400);
 return json({ok:true,signedIn:body.action==='verify'});
 }catch{return json({error:'Sign-in is temporarily unavailable. Please try again.'},503)}}
