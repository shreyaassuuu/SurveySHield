import {redirect} from 'next/navigation';
import {getViewer} from '../../lib/access';
import Workspace from '../../components/workspace';
export const dynamic='force-dynamic';
export default async function Admin(){const user=await getViewer();if(!user)redirect('/login');return <Workspace viewer={user}/>;}
