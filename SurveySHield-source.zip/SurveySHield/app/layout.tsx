import './globals.css';
export const metadata={title:'SurveySignal — Every response, a clearer picture',description:'Create surveys, explore responses and compare the perspectives that matter.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
