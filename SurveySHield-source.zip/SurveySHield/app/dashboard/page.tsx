import {redirect} from 'next/navigation';
import {getViewer} from '../../lib/access';
import UserDashboard from '../../components/user-dashboard';
export const dynamic='force-dynamic';
export default async function Dashboard(){const user=await getViewer();if(!user)redirect('/login');return <UserDashboard viewer={user}/>;}
