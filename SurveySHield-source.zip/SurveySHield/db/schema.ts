import { index, sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const surveys = sqliteTable('surveys', {id:text('id').primaryKey(),ownerId:text('owner_id'),data:text('data').notNull()},t=>[index('survey_owner_idx').on(t.ownerId)]);
export const responses = sqliteTable('responses', {id:text('id').primaryKey(),userId:text('user_id'),surveyId:text('survey_id').notNull().references(()=>surveys.id,{onDelete:'cascade'}),data:text('data').notNull()}, t=>[index('response_survey_idx').on(t.surveyId),index('response_user_idx').on(t.userId)]);
export const workspaceMeta = sqliteTable('workspace_meta',{key:text('key').primaryKey(),value:text('value').notNull()});

export const members=sqliteTable('members',{id:text('id').primaryKey(),email:text('email').notNull(),name:text('name').notNull(),role:text('role').notNull(),joinedAt:text('joined_at').notNull()});
