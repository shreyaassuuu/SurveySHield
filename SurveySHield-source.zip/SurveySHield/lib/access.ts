import {getExternalUser} from './supabase-server';
import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../app/chatgpt-auth';
export type Viewer = { userId:string; email:string; displayName:string; role:'admin'|'user' };
export async function getViewer():Promise<Viewer|null>{
 const identity=await getExternalUser()||await getChatGPTUser();
 if(!identity)return null;
 // ADMIN_EMAIL is a server-only deployment setting, never a browser-supplied role.
 const role=env.ADMIN_EMAIL&&identity.email.toLowerCase()===env.ADMIN_EMAIL.trim().toLowerCase()?'admin':'user';
 const viewer:Viewer={userId:identity.userId,email:identity.email,displayName:identity.fullName||identity.email.split('@')[0]||'Community member',role};
 await env.DB!.prepare('INSERT INTO members (id,email,name,role,joined_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,name=excluded.name,role=excluded.role').bind(viewer.userId,viewer.email,viewer.displayName,viewer.role,new Date().toISOString()).run();
 return viewer;
}
