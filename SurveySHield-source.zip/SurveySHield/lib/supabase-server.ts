import {createServerClient} from '@supabase/ssr';
import {cookies} from 'next/headers';
import {env} from 'cloudflare:workers';
export function authConfiguration(){const ready=Boolean(env.SUPABASE_URL&&env.SUPABASE_PUBLISHABLE_KEY);return {ready,email:ready&&env.AUTH_EMAIL_ENABLED!=='false',google:ready&&env.AUTH_GOOGLE_ENABLED==='true',phone:ready&&env.AUTH_PHONE_ENABLED==='true'};}
export async function authClient(writable=true){
 if(!authConfiguration().ready)return null;
 const jar=await cookies();
 return createServerClient(env.SUPABASE_URL!,env.SUPABASE_PUBLISHABLE_KEY!,{cookieOptions:{httpOnly:true,sameSite:'lax',secure:!import.meta.env.DEV,path:'/'},cookies:{getAll:()=>jar.getAll(),setAll(values){if(writable)for(const {name,value,options}of values)jar.set(name,value,options)}}});
}
export async function getExternalUser(){const supabase=await authClient(false);if(!supabase)return null;const {data,error}=await supabase.auth.getUser();if(error||!data.user)return null;const u=data.user;if(!u.email_confirmed_at&&!u.phone_confirmed_at)return null;return {userId:'sb:'+u.id,email:u.email_confirmed_at?u.email||'':'',fullName:typeof u.user_metadata?.full_name==='string'?u.user_metadata.full_name:null};}
